package com.josaca.ejerciciosud03p3

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.josaca.ejerciciosud03p3.ui.theme.EjerciciosUD03P3Theme
import kotlin.random.Random

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            EjerciciosUD03P3Theme {
                Surface {
                    Go(
                        modifier = Modifier.fillMaxSize()
                    )
                }
            }
        }
    }
}

@Composable
fun Go(modifier: Modifier = Modifier) {
    var numeroAleatorio by rememberSaveable { mutableStateOf<Int?>(null) }
    var binaryEnabled by rememberSaveable { mutableStateOf(false) }
    var hexaEnabled by rememberSaveable { mutableStateOf(false) }

    Column (modifier = modifier.fillMaxWidth().padding(vertical = 20.dp)) {

        Text(text = "Conversor numérico",
            fontSize = 40.sp,
            color = Color(255, 140, 51, 255),
            modifier = modifier.fillMaxWidth(),
            textAlign = TextAlign.Center
        )

        Box(modifier = modifier.fillMaxWidth(),
            contentAlignment = Alignment.Center) {
            Button(onClick = {
                if (numeroAleatorio != null) {
                    numeroAleatorio = null
                    binaryEnabled = false
                    hexaEnabled = false
                } else {
                    numeroAleatorio = Random.nextInt(0, 50000)
                }
            }, colors = ButtonDefaults.buttonColors(
                    containerColor = Color(255, 140, 51, 255)
                ),
            ) {
                Text(text = if (numeroAleatorio != null) "Borrar" else "Haz click para generar un número",
                    textAlign = TextAlign.Center)
            }
        }

        Text(text = numeroAleatorio?.toString() ?: "",
            fontSize = 70.sp,
            modifier = Modifier.height(100.dp).fillMaxWidth(),
            textAlign = TextAlign.Center,
            color = Color(255, 140, 51, 255))

        Row (modifier = modifier.fillMaxWidth().padding(horizontal = 5.dp),
            horizontalArrangement = Arrangement.SpaceBetween) {
            Button(enabled = (numeroAleatorio != null),
                onClick = {
                    binaryEnabled = true
                }) {
                Text("Convertir a binario")
            }
            if (binaryEnabled) {
                Text("b"+Integer.toBinaryString(numeroAleatorio ?: 0))
            }
        }

        Row (modifier = modifier.fillMaxWidth().padding(horizontal = 5.dp),
            horizontalArrangement = Arrangement.SpaceBetween) {
            Button(enabled = (numeroAleatorio != null),
                onClick = {
                    hexaEnabled = true
                }) {
                Text("Convertir a hexadecimal")
            }
            if (hexaEnabled) {
                Text("0x"+Integer.toHexString(numeroAleatorio ?: 0))
            }
        }

    }
}

@Preview(showBackground = true)
@Composable
fun GoPreview() {
    EjerciciosUD03P3Theme {
        Go()
    }
}