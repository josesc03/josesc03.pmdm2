package com.josaca.ejerciciosud03p3

import android.annotation.SuppressLint
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.josaca.ejerciciosud03p3.ui.theme.EjerciciosUD03P3Theme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            EjerciciosUD03P3Theme {
                Surface {
                    Go(
                        modifier = Modifier.fillMaxSize()
                    )
                }
            }
        }
    }
}

@SuppressLint("UnrememberedMutableState")
@Composable
fun Go(modifier: Modifier = Modifier) {
    var personas by rememberSaveable { mutableIntStateOf(0) }
    var patinetes by rememberSaveable { mutableIntStateOf(0) }
    var bicicletas by rememberSaveable { mutableIntStateOf(0) }
    var coches by rememberSaveable { mutableIntStateOf(0) }

    val total by derivedStateOf { personas + patinetes + bicicletas + coches }


    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(vertical = 20.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {

        Text(
            text = "Estadísticas UD03",
            fontSize = 40.sp,
            modifier = modifier.fillMaxWidth(),
            textAlign = TextAlign.Center
        )

        Spacer(modifier = modifier.height(20.dp))

        Row(
            modifier = modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Total: $total")
            Spacer(Modifier.padding(horizontal = 10.dp))
            Button(
                onClick = {
                    personas = 0
                    patinetes = 0
                    bicicletas = 0
                    coches = 0
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(85, 83, 89, 255)
                )
            ) {
                Text(
                    text = "Reiniciar todos",
                    textAlign = TextAlign.Center
                )
            }
        }

        Spacer(modifier = modifier.height(20.dp))

        Text(
            text = "Personas:",
            modifier = Modifier.fillMaxWidth(),
            textAlign = TextAlign.Center,
        )

        Row(
            modifier = modifier
                .fillMaxWidth()
                .padding(horizontal = 5.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                personas.toString(),
                fontSize = 20.sp
            )
            Button(
                onClick = {
                    personas++
                }, colors = ButtonDefaults.buttonColors(
                    containerColor = Color(102, 184, 106, 255)
                )
            ) { Text("+1") }
            Button(
                onClick = {
                    if (personas > 0) {
                        personas--
                    }
                }, enabled = personas > 0,
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(156, 165, 159, 255)
                )
            ) { Text("-1") }
            Button(
                onClick = {
                    personas = 0
                }, enabled = personas > 0,
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(85, 83, 89, 255)
                )
            ) { Text("Reset") }
        }

        Spacer(modifier = modifier.height(20.dp))

        Text(
            text = "Patinetes:",
            modifier = Modifier.fillMaxWidth(),
            textAlign = TextAlign.Center,
        )

        Row(
            modifier = modifier
                .fillMaxWidth()
                .padding(horizontal = 5.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                patinetes.toString(),
                fontSize = 20.sp
            )
            Button(
                onClick = {
                    patinetes++
                }, colors = ButtonDefaults.buttonColors(
                    containerColor = Color(102, 184, 106, 255)
                )
            ) { Text("+1") }
            Button(
                onClick = {
                    if (patinetes > 0) {
                        patinetes--
                    }
                }, enabled = patinetes > 0,
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(156, 165, 159, 255)
                )
            ) { Text("-1") }
            Button(
                onClick = {
                    patinetes = 0
                },
                enabled = patinetes > 0,
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(85, 83, 89, 255)
                )
            ) { Text("Reset") }
        }

        Spacer(modifier = modifier.height(20.dp))

        Text(
            text = "Bicicletas:",
            modifier = Modifier.fillMaxWidth(),
            textAlign = TextAlign.Center,
        )

        Row(
            modifier = modifier
                .fillMaxWidth()
                .padding(horizontal = 5.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                bicicletas.toString(),
                fontSize = 20.sp
            )
            Button(
                onClick = {
                    bicicletas++
                }, colors = ButtonDefaults.buttonColors(
                    containerColor = Color(102, 184, 106, 255)
                )
            ) { Text("+1") }
            Button(
                onClick = {
                    if (bicicletas > 0) {
                        bicicletas--
                    }
                }, enabled = bicicletas > 0,
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(156, 165, 159, 255)
                )
            ) { Text("-1") }
            Button(
                onClick = {
                    bicicletas = 0
                }, enabled = bicicletas > 0,
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(85, 83, 89, 255)
                )
            ) { Text("Reset") }
        }

        Spacer(modifier = modifier.height(20.dp))

        Text(
            text = "Coches:",
            modifier = Modifier.fillMaxWidth(),
            textAlign = TextAlign.Center,
        )

        Row(
            modifier = modifier
                .fillMaxWidth()
                .padding(horizontal = 5.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                coches.toString(),
                fontSize = 20.sp
            )
            Button(
                onClick = {
                    coches++
                }, colors = ButtonDefaults.buttonColors(
                    containerColor = Color(102, 184, 106, 255)
                )
            ) { Text("+1") }
            Button(
                onClick = {
                    if (coches > 0) {
                        coches--
                    }
                }, enabled = coches > 0,
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(156, 165, 159, 255)
                )
            ) { Text("-1") }
            Button(
                onClick = {
                    coches = 0
                }, enabled = coches > 0,
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(85, 83, 89, 255)
                )
            ) { Text("Reset") }
        }

        Spacer(modifier = modifier.height(15.dp))

        Column(
            modifier = modifier.width(150.dp),
        ) {
            Text("Estadísticas", textAlign = TextAlign.Center, modifier = modifier.fillMaxWidth())
            Text(
                "Personas: ${if (total > 0) (personas * 100 / total) else 0}%",
                textAlign = TextAlign.Left
            )
            Text(
                "Patinetes: ${if (total > 0) (patinetes * 100 / total) else 0}%",
                textAlign = TextAlign.Left
            )
            Text(
                "Bicicletas: ${if (total > 0) (bicicletas * 100 / total) else 0}%",
                textAlign = TextAlign.Left
            )
            Text(
                "Coches: ${if (total > 0) (coches * 100 / total) else 0}%",
                textAlign = TextAlign.Left
            )
        }

    }
}

@Preview(showBackground = true)
@Composable
fun GoPreview() {
    EjerciciosUD03P3Theme {
        Go()
    }
}