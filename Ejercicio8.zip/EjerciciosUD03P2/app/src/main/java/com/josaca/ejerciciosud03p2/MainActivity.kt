package com.josaca.ejerciciosud03p2

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.josaca.ejerciciosud03p2.ui.theme.EjerciciosUD03P2Theme
import kotlinx.coroutines.delay

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            EjerciciosUD03P2Theme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    Go(
                        modifier = Modifier.padding(5.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun Go(modifier: Modifier = Modifier) {
    var time by rememberSaveable { mutableIntStateOf(10) }
    var tempOn by rememberSaveable { mutableStateOf(false) }

    LaunchedEffect(tempOn) {
        if (tempOn) {
            while (time > 0) {
                delay(1000L)
                time--
            }
            tempOn = false
        }
    }

    Column(
        modifier = modifier,
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = if (time != 0) "Segundos restantes: $time" else "¡Tiempo terminado!",
            fontSize = 25.sp
        )
        Button(onClick = { tempOn = true; time = 10 })
        {
            Text(
                text = if (tempOn) "Contando" else "Comenzar",
                fontSize = 20.sp
            )
        }
    }
}